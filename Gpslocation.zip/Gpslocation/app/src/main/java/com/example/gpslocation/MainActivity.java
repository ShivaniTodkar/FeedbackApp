package com.example.gpslocation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationProvider;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText e1;
    Button b1;
    private FusedLocationProviderClient client;
    Geocoder geocoder;
    List<Address> addresses;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editText);
        b1=findViewById(R.id.button);

        geocoder=new Geocoder(this, Locale.getDefault());
        requestpermission();
        client= LocationServices.getFusedLocationProviderClient(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {
                if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED )
                {
                   // && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)!=
                }
                client.getLastLocation().addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                       //Toast.makeText(getApplicationContext(),"Location",Toast.LENGTH_LONG).show();
                      if(location!=null)
                      {
                         Double s1=location.getLatitude();
                          Double s2=location.getLongitude();
                         // String s11=s1.toString();
                          //String s22=s2.toString();
                          try {
                              addresses = geocoder.getFromLocation(s1, s2, 1);
                              String address=addresses.get(0).getAddressLine(0);
                              String area=addresses.get(0).getLocality();
                              String city=addresses.get(0).getAdminArea();
                              String country=addresses.get(0).getCountryName();
                              String Fulladdress=address+","+area+","+city+","+country;
                              e1.setText(Fulladdress);
                              Toast.makeText(getApplicationContext(),"Location"+Fulladdress,Toast.LENGTH_LONG).show();

                          }
                           catch (IOException e) {
                              e.printStackTrace();
                          }

                        //  e1.setText();

                      }
                    }
                });
            }
        });
    }
    private void requestpermission()
    {
      ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
    }
}
