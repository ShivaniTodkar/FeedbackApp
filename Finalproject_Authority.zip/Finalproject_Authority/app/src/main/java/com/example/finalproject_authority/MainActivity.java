package com.example.finalproject_authority;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    //private static int Splash_time_out=4000;

    Button b1;
    private FirebaseAuth firebaseAuth;
    EditText user1,pass;
    String email;
    int counter=5;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=findViewById(R.id.login);
        user1=findViewById(R.id.username);
        pass=findViewById(R.id.password);
        firebaseAuth= FirebaseAuth.getInstance();
        final FirebaseUser user=firebaseAuth.getCurrentUser();
        if(user !=null)
        {
            finish();
            Intent i= new Intent(MainActivity.this,Home_page.class);
            startActivity(i);
        }
        progressDialog=new ProgressDialog(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()) {
                    validate(user1.getText().toString().trim(),pass.getText().toString().trim());
                    //Intent i1 = new Intent(MainActivity.this, Home_page.class);
                    //startActivity(i1);
                }
            }
        });
    }

    private Boolean validateemail()
    {
        // Boolean result=true;
        final String e1="shubhalijadhav206@gmail.com";
        email =user1.getText().toString().trim();
        //String pass=e2.getText().toString();
        if(email.isEmpty())
        {
            user1.setError("Field can't be empty");
            return false;
        }
        else if (email.equals(e1))
        {
            user1.setError(null);
            return true;
        }
        else
        {
            user1.setError("Enter Valid UserName");
            return false;
        }

    }

    private Boolean validatepassword()
    {
        // Boolean result=true;
        String password =pass.getText().toString().trim();
        final  String password1="12345678";

        if(email.isEmpty())
        {
            pass.setError("Field can't be empty");
            return false;
        }
        else if (password.equals(password1))
        {
            pass.setError(null);
            return true;
        }
        else {

            pass.setError("Enter Correct Password");
            return false;
        }

    }
    public Boolean validate()
    {
        if(!validateemail()|!validatepassword())
            return false;
        else
            return true;
    }
    private void validate(String name,String password)
    {

        progressDialog.setMessage("Wait for minute");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(name,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    progressDialog.dismiss();
                    // Intent i1=new Intent(MainActivity.this,ImageAdapter.class);
                    //i1.putExtra("useremail",email);

                    Toast.makeText(getApplicationContext(),"Login Successful", Toast.LENGTH_LONG).show();
                    Intent i=new Intent(MainActivity.this,Home_page.class);
                    startActivity(i);

                }
                else
                {

                    Toast.makeText(getApplicationContext(),"Login Failed",Toast.LENGTH_LONG).show();
                    counter--;

                    progressDialog.dismiss();
                    if(counter==0)
                    {
                        b1.setEnabled(false);
                    }
                }

            }
        });
    }
    }
