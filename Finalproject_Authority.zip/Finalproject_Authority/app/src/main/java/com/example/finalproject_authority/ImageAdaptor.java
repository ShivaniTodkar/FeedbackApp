package com.example.finalproject_authority;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ImageAdaptor extends RecyclerView.Adapter<ImageAdaptor.MyviewHolder> {
    private Context mcontext;
    private List<Upload> profiles;
  int f=0;
    public ImageAdaptor(Context mcontext, List<Upload> profiles) {
        this.mcontext = mcontext;
        this.profiles = profiles;
    }

    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyviewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item1, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final MyviewHolder myviewHolder, int i) {
       final Upload p = profiles.get(i);
        myviewHolder.name.setText(p.getImgname());
        myviewHolder.loc1.setText(p.getLoc());
        myviewHolder.desc1.setText(p.getDesc());
        myviewHolder.email1.setText(p.getEmail());
        Picasso.get().load(profiles.get(i).getImgUri()).into(myviewHolder.profilepic);
            myviewHolder.btn.setVisibility(View.VISIBLE);
            myviewHolder.btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    f++;
                    Intent i1 = new Intent(mcontext, Reply.class);
                    final Intent intent1=i1.putExtra("Iname",p.getImgname());
                    final Intent intent = i1.putExtra("Email",p.getEmail());
                    mcontext.startActivity(i1);

                }
            });


    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    class MyviewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public TextView loc1;
        public TextView desc1;
        public ImageView profilepic;
        public TextView email1;
        public Button btn;

        public MyviewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.Iname);
            loc1 = itemView.findViewById(R.id.loc);
            desc1 = itemView.findViewById(R.id.dec);
            profilepic = itemView.findViewById(R.id.roadimg);
            email1=itemView.findViewById(R.id.em);
            btn = itemView.findViewById(R.id.reply);
        }

    }
}