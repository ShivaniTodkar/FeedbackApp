package com.example.finalproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.icu.text.IDNA;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
private EditText e1,e2;
//private TextInputLayout e1,e2;
private Button b1,b2;
private FirebaseAuth firebaseAuth;
private String user_name,user_password;
private ProgressDialog progressDialog;
private int counter =5;
private String email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.login);
        b2=findViewById(R.id.register);
        e1=findViewById(R.id.email);
        e2=findViewById(R.id.password);
        firebaseAuth=FirebaseAuth.getInstance();
        FirebaseUser user=firebaseAuth.getCurrentUser();
        //String user1=firebaseAuth.getCurrentUser().getEmail().toString();
        //String ss=user.getEmail().toString()
        Toast.makeText(getApplicationContext(),"user",Toast.LENGTH_LONG).show();
        if(user !=null)
        {
            finish();
            Intent i= new Intent(MainActivity.this,Homepage.class);
            startActivity(i);
        }

        progressDialog=new ProgressDialog(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Boolean s1=validate();
               // Toast.makeText(getApplicationContext(),"value of s is"+s1,Toast.LENGTH_LONG).show();

               if(validate())
                {
                    validate(e1.getText().toString().trim(),e2.getText().toString().trim());

                   // Intent i=new Intent(MainActivity.this,Homepage.class);
                    //startActivity(i);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Enter EmailID and Password", Toast.LENGTH_LONG).show();
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,register.class);
                startActivity(i);
            }
        });
    }
   /* private  Boolean validate()
    {
        Boolean result=false;
       // String name=user_name.getText().toString();
        email=e1.getText().toString().trim();
        String password=e2.getText().toString();

        if(email.isEmpty() || password.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Please enter all the details",Toast.LENGTH_LONG).show();
        }
        else
        {
            result=true;
        }
        return result;
    }*/
   private Boolean validateemail()
   {
      // Boolean result=true;
       email =e1.getText().toString().trim();
       //String pass=e2.getText().toString();
       if(email.isEmpty())
       {
           e1.setError("Field can't be empty");
           return false;
       }
       else
       {
           e1.setError(null);
           return true;
       }

   }

    private Boolean validatepassword()
    {
        // Boolean result=true;
        String password =e2.getText().toString().trim();

        if(email.isEmpty())
        {
            e2.setError("Field can't be empty");
            return false;
        }
        else if (password.length()<6)
        {
            e2.setError("Password must contain more than 6 character");
            return false;
        }
        else {
            e2.setError(null);
            return true;
        }

    }
    public Boolean validate()
    {
        if(!validateemail()|!validatepassword())
            return false;
        else
            return true;
    }
    private void validate(String name,String password)
    {

        progressDialog.setMessage("Wait for minute you are ");
        progressDialog.show();
        firebaseAuth.signInWithEmailAndPassword(name,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
           if(task.isSuccessful()){
               progressDialog.dismiss();
              // Intent i1=new Intent(MainActivity.this,ImageAdapter.class);
               //i1.putExtra("useremail",email);

               Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_LONG).show();
               Intent i=new Intent(MainActivity.this,Homepage.class);
               startActivity(i);

           }
           else
           {

               Toast.makeText(getApplicationContext(),"Login Failed",Toast.LENGTH_LONG).show();
               counter--;

               progressDialog.dismiss();
               if(counter==0)
               {
                   b1.setEnabled(false);
               }
           }

            }
        });
    }

}
