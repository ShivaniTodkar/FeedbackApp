package com.example.finalproject;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class replyadapter extends RecyclerView.Adapter<replyadapter.MyviewHolder>{
    private Context mcontext;
    private List<Upload> profiles;

    public replyadapter(Context mcontext, List<Upload> profiles) {
        this.mcontext = mcontext;
        this.profiles = profiles;
    }

    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyviewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item1, viewGroup, false));

    }

    @Override
    public void onBindViewHolder(@NonNull MyviewHolder myviewHolder, int i) {
        Upload p = profiles.get(i);
        myviewHolder.name.setText(p.getImgname());
        myviewHolder.loc1.setText(p.getLoc());
        myviewHolder.desc1.setText(p.getDesc());
        myviewHolder.email.setText(p.getEmail());
        Picasso.get().load(profiles.get(i).getImgUri()).into(myviewHolder.profilepic);

    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    class MyviewHolder extends RecyclerView.ViewHolder  {
        public TextView name;
        public TextView loc1;
        public TextView desc1;
        public ImageView profilepic;
        public TextView email;
        public Button btn;

        public MyviewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.Iname);
            loc1 = itemView.findViewById(R.id.loc);
            desc1 = itemView.findViewById(R.id.dec);
            email=itemView.findViewById(R.id.email2);
            profilepic = itemView.findViewById(R.id.roadimg);
           // btn = itemView.findViewById(R.id.reply);
        }

    }
}
