package com.example.finalproject;

public class Retrive {
    public String imgname;
    public String loc;
    public String desc;
    public String imgUri;
    public String email;

    public Retrive(String imgname, String loc, String desc, String imgUri, String email) {
        this.imgname = imgname;
        this.loc = loc;
        this.desc = desc;
        this.imgUri = imgUri;
        this.email = email;
    }

    public String getImgname() {
        return imgname;
    }

    public void setImgname(String imgname) {
        this.imgname = imgname;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImgUri() {
        return imgUri;
    }

    public void setImgUri(String imgUri) {
        this.imgUri = imgUri;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
