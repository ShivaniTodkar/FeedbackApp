package com.example.finalproject;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.List;
public class ImageAdaptor extends RecyclerView.Adapter<ImageAdaptor.ImageViewHolder>{
    private Context mcontext;
    private List<Upload> profiles;

    public ImageAdaptor(Context c, List<Upload> p) {
        this.mcontext =c;
        this.profiles = p;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ImageViewHolder(LayoutInflater.from(mcontext).inflate(R.layout.imageitem,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder imageViewHolder, int i) {
        Upload p=profiles.get(i);
        imageViewHolder.name.setText(p.getImgname());
        imageViewHolder.loc1.setText(p.getLoc());
        imageViewHolder.desc1.setText(p.getImgUri());
        imageViewHolder.email1.setText(p.getEmail());
        Picasso.get().load(profiles.get(i).getImgUri()).into(imageViewHolder.profilepic);
    }

    @Override
    public int getItemCount() {
        return profiles.size();
    }

    class ImageViewHolder extends RecyclerView.ViewHolder{
        public TextView name;
        public TextView loc1;
        public TextView desc1;
        public TextView email1;
        public ImageView profilepic;
        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.imageName);
            loc1=itemView.findViewById(R.id.location1);
            desc1=itemView.findViewById(R.id.desc);
            profilepic=itemView.findViewById(R.id.imageView);
            email1=itemView.findViewById(R.id.email2);
        }
    }
}
