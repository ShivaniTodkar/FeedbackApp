package com.example.finalproject;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class UploadImage extends AppCompatActivity {
Button select,send;
EditText name,location1,description;
ImageView iv;
private StorageReference storageReference;
private DatabaseReference databaseReference;
ProgressDialog progressDialog;
    private FusedLocationProviderClient client;
    Geocoder geocoder;
    List<Address> addresses;
    int select_file=100,REQUEST_CAMERA=1;
    Uri selectdImageUri;

    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private StorageTask mUploadtask;
    String Fulladdress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_image);
        select=findViewById(R.id.selectbtn);
        send=findViewById(R.id.sendbtn);
        name=findViewById(R.id.nameofimage);
        iv=findViewById(R.id.image);
        firebaseAuth=FirebaseAuth.getInstance();
        location1=findViewById(R.id.location1);
        description=findViewById(R.id.description);
        firebaseAuth=FirebaseAuth.getInstance();
        progressDialog=new ProgressDialog(this);

        storageReference= FirebaseStorage.getInstance().getReference("Images");
        databaseReference= FirebaseDatabase.getInstance().getReference("Images");
        user=FirebaseAuth.getInstance().getCurrentUser();

        geocoder=new Geocoder(this, Locale.getDefault());
        requestpermission();
        client= LocationServices.getFusedLocationProviderClient(this);
        select.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {
                SelectImage();
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()) {
                    uploadImage();
                }
            }
        });
    }
    private String getFileExtension(Uri uri)
    {
        ContentResolver contentResolver=getContentResolver();
        MimeTypeMap mimeTypeMap=MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void uploadImage()
    {
        progressDialog.setMessage("Wait for minute");
        progressDialog.show();
        final String email=user.getEmail();
        final String Iname=name.getText().toString();
        final String loc=location1.getText().toString();
        final String desc=description.getText().toString();
        final StorageReference fileref=storageReference.child(Iname).child(System.currentTimeMillis()+"."+getFileExtension(selectdImageUri));
        mUploadtask=fileref.putFile(selectdImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Uri downloadurl=uri;
                        String fileurl=downloadurl.toString();
                        Upload upload=new Upload(Iname,loc,desc,fileurl,email);
                        String uploadID=databaseReference.push().getKey();
                        databaseReference.child(Iname).setValue(upload);
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(),"OKK"+user.toString(),Toast.LENGTH_LONG).show();

                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Updated Failed", Toast.LENGTH_LONG).show();
            }
        });
    }


    private void SelectImage()
    {
        final CharSequence[] items={"Camera","Gallery","Cancel"};
        AlertDialog.Builder builder=new AlertDialog.Builder(UploadImage.this);
        builder.setTitle("Add image");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                if(items[i].equals("Camera"))
                {
                    Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent,REQUEST_CAMERA);
                }
                else if(items[i].equals("Gallery"))
                {
                    Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent.createChooser(intent,"Select File"),select_file);
                }
                else if(items[i].equals("Cancel"))
                {

                }
            }
        });
        builder.show();
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode== Activity.RESULT_OK)
        {
            if(requestCode==REQUEST_CAMERA)
            {
                Bundle bundle=data.getExtras();
                final Bitmap imp=(Bitmap) bundle.get("data");
                iv.setImageBitmap(imp);
                selectdImageUri=data.getData();
            }
            if(requestCode==select_file)
            {
                selectdImageUri=data.getData();
                iv.setImageURI(selectdImageUri);
            }
        }
        getlocation();

    }
    private void getlocation()
    {
        if(ActivityCompat.checkSelfPermission(UploadImage.this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED )
        {
            // && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)!=
        }
        client.getLastLocation().addOnSuccessListener(UploadImage.this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                //Toast.makeText(getApplicationContext(),"Location",Toast.LENGTH_LONG).show();
                if(location!=null)
                {
                    Double s1=location.getLatitude();
                    Double s2=location.getLongitude();
                    // String s11=s1.toString();
                    //String s22=s2.toString();
                    try {
                        addresses = geocoder.getFromLocation(s1, s2, 1);
                        String address=addresses.get(0).getAddressLine(0);
                        String area=addresses.get(0).getLocality();
                        String city=addresses.get(0).getAdminArea();
                        //String country=addresses.get(0).getCountryName();
                        Fulladdress=address+area;
                        location1.setText(Fulladdress);
                        location1.setEnabled(false);
                        //Toast.makeText(getApplicationContext(),"Location"+Fulladdress,Toast.LENGTH_LONG).show();

                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }

                    //  e1.setText();

                }
            }
        });

    }
    private void requestpermission()
    {
        ActivityCompat.requestPermissions(UploadImage.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
    }
    private Boolean validatename()
    {
        // Boolean result=true;
        String name1 =name.getText().toString().trim();

        if(name1.isEmpty())
        {
            name.setError("Field can't be empty");
            return false;
        }
        else {
            name.setError(null);
            return true;
        }

    }
    private Boolean validatediscription()
    {
        // Boolean result=true;
        String dis =description.getText().toString().trim();

        if(dis.isEmpty())
        {
            description.setError("Field can't be empty");
            return false;
        }
        else {
            description.setError(null);
            return true;
        }

    }
    public Boolean validate()
    {
        if(!validatename() | !validatediscription())
            return false;
        else
            return true;
    }
}
