package com.example.finalproject;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity {
    EditText e1, e2, e3, e4;
    Button b1;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        b1 = findViewById(R.id.register);
        e1 = findViewById(R.id.email1);
        e2 = findViewById(R.id.pass1);
        e3 = findViewById(R.id.pass2);
        e4 = findViewById(R.id.name);

        firebaseAuth = FirebaseAuth.getInstance();
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String username = e4.getText().toString().trim();
                final String emailid = e1.getText().toString().trim();
                final String pass1 = e2.getText().toString().trim();
                String pass2 = e3.getText().toString().trim();
                int password1_size = pass1.length();
                int password2_size = pass2.length();

                if (validate()) {
                    if (pass1.equals(pass2)) {
                        firebaseAuth.createUserWithEmailAndPassword(emailid, pass1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
                                    DatabaseReference myref = firebaseDatabase.getReference("Images").child(firebaseAuth.getUid());
                                    registerclass registerclass = new registerclass(username, emailid, pass1);
                                    myref.setValue(registerclass);
                                    Toast.makeText(getApplicationContext(), "okk", Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(register.this, MainActivity.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    } else {
                        Toast.makeText(getApplicationContext(), "Enter correct password", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });
    }

    /* private  Boolean validate()
     {
         Boolean result=false;
         String email=e1.getText().toString().trim();
         String pass1=e2.getText().toString().trim();
         String pass2=e3.getText().toString().trim();
         if(email.isEmpty() || pass1.isEmpty() || pass2.isEmpty())
         {
             Toast.makeText(getApplicationContext(),"Please enter all the details",Toast.LENGTH_LONG).show();
         }
         else
         {
             result=true;

         }
         return result;
     }*/
    private Boolean validatename() {
        String name = e4.getText().toString().trim();
        //
        //
        //
        if (name.isEmpty()) {
            e4.setError("Enter your name");
            return false;
        } else {
            e4.setError(null);
            return true;
        }
    }

    private Boolean validateEmail() {
        String email = e1.getText().toString().trim();
        if (email.isEmpty()) {
            e1.setError("Enter valid email address");
            return false;
        } else {
            e1.setError(null);
            return true;
        }
    }

    private Boolean validatePass() {
        String pass1 = e2.getText().toString().trim();
        if (pass1.isEmpty()) {
            e2.setError("Enter password");
            return false;
        } else if (pass1.length() < 6) {
            e2.setError("Password must contain 6 characters");
            return false;
        } else {
            e2.setError(null);
            return true;
        }
    }

    private Boolean validatepass2() {
        String pass2 = e3.getText().toString().trim();
        if (pass2.isEmpty()) {
            e3.setError("ReEnter password");
            return false;
        } else {
            e3.setError(null);
            return true;
        }
    }

    public Boolean validate()
    {
        if(!validatename() | !validateEmail() |!validatePass() | !validatepass2())
        {
            return false;
        }
        return true;
    }


}

