package com.example.firebaselogin;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private EditText user_name,user_password,user_email;
    private Button register;
    private TextView t1;
    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        user_name=findViewById(R.id.username);
        user_email=findViewById(R.id.useremail);
        user_password=findViewById(R.id.password);
        register=findViewById(R.id.register);
        t1=findViewById(R.id.textView1);

        firebaseAuth=FirebaseAuth.getInstance();


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Boolean r=validate();

                if(validate())
                {
                    //upload data to the datadase
                    String u_email=user_email.getText().toString().trim();
                    String u_pass=user_password.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(u_email,u_pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Toast.makeText(MainActivity.this, "Registration Successful", Toast.LENGTH_LONG).show();
                            Intent i = new Intent(MainActivity.this, login.class);
                            startActivity(i);

                        } else {
                            Toast.makeText(MainActivity.this, "Registration not Successful", Toast.LENGTH_LONG).show();
                        }
                    }

                    });

                }
               // Toast.makeText(MainActivity.this, "Registration Successful", Toast.LENGTH_LONG).show();
                //Intent i = new Intent(MainActivity.this, login.class);
                //startActivity(i);
            }
        });
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,login.class);
                startActivity(i);
            }
        });

    }
    private  Boolean validate()
    {
        Boolean result=false;
        String name=user_name.getText().toString();
        String password=user_password.getText().toString();
        String email=user_email.getText().toString();
        if(name.isEmpty() || password.isEmpty() || email.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Please enter all the details",Toast.LENGTH_LONG).show();
        }
        else
        {
            result=true;

        }
        return result;
    }
}
